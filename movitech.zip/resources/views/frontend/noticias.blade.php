@extends('layouts.frontend')
@section('contenido')

<livewire:viewnoticias />

@stop