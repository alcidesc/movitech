@extends('layouts.frontend')
@section('contenido')

	@livewire('pricing', ['limite' => 2])
@stop