@extends('layouts.frontend')
@section('contenido')
    <livewire:acerca>
@stop