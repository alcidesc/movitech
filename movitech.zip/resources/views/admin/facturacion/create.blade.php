@extends('adminlte::page')

@section('title', 'Facturación')

@section('content_header')
 	<h1>Facturación</h1><hr>
@stop

@section('content')
	<livewire:facturacioncreate />
@stop