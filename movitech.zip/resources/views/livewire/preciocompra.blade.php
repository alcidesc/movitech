<div>
    @if($compra)
        {{$compra->precio}}
    @else
        0
    @endif
</div>
