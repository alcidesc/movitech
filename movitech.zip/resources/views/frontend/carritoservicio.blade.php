@extends('layouts.frontend')
@section('contenido')
	<livewire:carritoservicio />
@stop