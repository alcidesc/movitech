@extends('layouts.frontend')
@section('contenido')

	<livewire:agendarcita />
@stop