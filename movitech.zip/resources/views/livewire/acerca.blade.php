<div>
	<section class="w3l-team-main team py-5" id="team">
        <div class="container py-lg-5">
            <div class="text-center mb-2">
				<h3 class="title-w3l mb-4">{{ $empresa->nombre }}</h3>
            </div>
            <div class="row team-row justify-content-center">
				<div class="col-md-12">
					<p><?=  $empresa->info  ?></p>	
				</div>
			</div>
		</div>
	</section>
</div>