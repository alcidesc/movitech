@extends('layouts.frontend')
@section('contenido')
	<livewire:carritos />
@stop